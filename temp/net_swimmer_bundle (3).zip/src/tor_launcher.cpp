
#include "tor_launcher.h"
#include <windows.h>
#include <iostream>
#include <fstream>
#include <thread>
#include <chrono>

bool startTorWithProxy(const std::string& proxy) {
    std::string torPath = "tor\\tor.exe";
    std::string torrcPath = "tor\\torrc";

    std::ifstream f(torPath);
    if (!f.good()) {
        std::cerr << "[tor_launcher] ❌ Missing tor.exe in tor/ folder.\n";
        return false;
    }

    std::string cmd = """ + torPath + "" -f "" + torrcPath + """;
    std::cout << "[tor_launcher] 🔁 Launching Tor: " << cmd << "\n";

    STARTUPINFOA si = { sizeof(si) };
    PROCESS_INFORMATION pi;

    BOOL success = CreateProcessA(NULL,
                                  (LPSTR)cmd.c_str(),
                                  NULL,
                                  NULL,
                                  FALSE,
                                  CREATE_NO_WINDOW,
                                  NULL,
                                  NULL,
                                  &si,
                                  &pi);

    if (!success) {
        std::cerr << "[tor_launcher] ❌ Failed to start Tor process.\n";
        return false;
    }

    std::cout << "[tor_launcher] ⏳ Waiting 10s for Tor to bootstrap...\n";
    std::this_thread::sleep_for(std::chrono::seconds(10));

    return true;
}
