
#pragma once
#include <string>

bool startTorWithProxy(const std::string& proxy);
