#pragma once
#include <string>

bool sendJsonViaTor(const std::string& json);