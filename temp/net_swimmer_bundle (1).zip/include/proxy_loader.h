
#pragma once
#include <string>
#include <vector>

std::vector<std::string> loadProxies(const std::string& path);
