
#pragma once
#include <string>

bool isAdmin();
std::string currentDateTime();
