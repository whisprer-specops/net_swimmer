
#pragma once
#include <string>

bool mailHome(const std::string& url, const std::string& jsonPayload);
