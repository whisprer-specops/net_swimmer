
#include "mail_home.h"
#include <windows.h>
#include <winhttp.h>
#include <iostream>

#pragma comment(lib, "winhttp.lib")

bool mailHome(const std::string& url, const std::string& jsonPayload) {
    URL_COMPONENTS urlComp = { sizeof(urlComp) };
    wchar_t hostName[256], urlPath[1024];
    DWORD port = INTERNET_DEFAULT_HTTPS_PORT;

    std::wstring urlW(url.begin(), url.end());

    urlComp.lpszHostName = hostName;
    urlComp.dwHostNameLength = sizeof(hostName) / sizeof(wchar_t);
    urlComp.lpszUrlPath = urlPath;
    urlComp.dwUrlPathLength = sizeof(urlPath) / sizeof(wchar_t);
    WinHttpCrackUrl(urlW.c_str(), urlW.length(), 0, &urlComp);

    HINTERNET hSession = WinHttpOpen(L"net_swimmer/1.0",
                                     WINHTTP_ACCESS_TYPE_NO_PROXY,
                                     WINHTTP_NO_PROXY_NAME,
                                     WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) return false;

    HINTERNET hConnect = WinHttpConnect(hSession, urlComp.lpszHostName,
                                        urlComp.nPort, 0);
    if (!hConnect) {
        WinHttpCloseHandle(hSession);
        return false;
    }

    HINTERNET hRequest = WinHttpOpenRequest(hConnect, L"POST", urlComp.lpszUrlPath,
                                            NULL, WINHTTP_NO_REFERER,
                                            WINHTTP_DEFAULT_ACCEPT_TYPES,
                                            WINHTTP_FLAG_SECURE);
    if (!hRequest) {
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return false;
    }

    std::wstring headers = L"Content-Type: application/json
";
    std::wstring body(jsonPayload.begin(), jsonPayload.end());

    BOOL result = WinHttpSendRequest(hRequest,
                                     headers.c_str(), -1,
                                     (LPVOID)body.c_str(), body.length(),
                                     body.length(), 0);
    if (!result) {
        WinHttpCloseHandle(hRequest);
        WinHttpCloseHandle(hConnect);
        WinHttpCloseHandle(hSession);
        return false;
    }

    result = WinHttpReceiveResponse(hRequest, NULL);

    WinHttpCloseHandle(hRequest);
    WinHttpCloseHandle(hConnect);
    WinHttpCloseHandle(hSession);

    return result;
}
